package dao;

import java.util.HashMap;
import java.util.Map;

import vo.User;

public class UserDao {

	private Map<String, User> db = new HashMap<>();
	public UserDao(){
		db.put("kong", new User("홍진호","kong","zxcv1234","kong@gmail.com"));
		db.put("boxer", new User("임요환","boxer","zxcv1234","boxer@gmail.com"));
		db.put("reach", new User("박정석","reach","zxcv1234","reach@gmail.com"));
		db.put("nada", new User("이윤열","nada","zxcv1234","nada@gmail.com"));
	}
	public User getUserById(String userid){
		User user = db.get(userid);
		return user;
	}
}
